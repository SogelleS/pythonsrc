# 包是一个特殊的目录
# 包里有多个模块，使用import可以一次性导入包里的模块
# 包目录下有一个特殊的文件 __init__.py

from . import send_message
from . import receive_message





