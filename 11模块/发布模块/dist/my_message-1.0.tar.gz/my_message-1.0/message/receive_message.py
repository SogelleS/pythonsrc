def receive():
    return 'this message from XXX'


