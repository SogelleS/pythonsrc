from distutils.core import setup


setup(name="my_message",
      version="1.0",
      description="itheima's 发送和接收消息模块",
      long_description="完整的发送和接收消息模块",
      author="dyf", 
      py_modules=["message.send_message", "message.receive_message"])




